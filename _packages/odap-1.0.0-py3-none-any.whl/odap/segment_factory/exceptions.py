class SegmentNotFoundException(Exception):
    pass
