from typing import Dict, Any
from odap.common.config import ConfigNamespace

from odap.common.exceptions import ConfigAttributMissingException, InvalidConfigAttributException

SEGMENT_FACTORY = ConfigNamespace.SEGMENT_FACTORY.value


def get_segment_table(segment: str, config: Dict[str, Any]) -> str:
    segment_table = config.get("table", None)

    if not segment_table:
        raise ConfigAttributMissingException(
            f"'{SEGMENT_FACTORY}.table' not defined in config.yaml"
        )

    if not "{segment}" in segment_table:
        raise InvalidConfigAttributException(
            f"Configuration attribute '{SEGMENT_FACTORY}.table' is in the wrong format'"
        )

    return str(segment_table).replace("{segment}", segment)


def get_segment_table_path(segment: str, config: Dict[str, Any]) -> str:
    segment_path = config.get("path", None)

    if not segment_path:
        raise ConfigAttributMissingException(
            f"'{SEGMENT_FACTORY}.path' not defined in config.yaml"
        )

    if not "{segment}" in segment_path:
        raise InvalidConfigAttributException(
            f"Configuration attribute '{SEGMENT_FACTORY}.path' is in the wrong format'"
        )

    return str(segment_path).replace("{segment}", segment)


def get_segments(config: Dict[str, Any]) -> Dict[str, Any]:
    segments_dict = config.get("segments", None)

    if not segments_dict:
        raise ConfigAttributMissingException(
            f"'{SEGMENT_FACTORY}.segments' not defined in config.yaml"
        )

    return segments_dict


def get_segment(segment_name:str, config: Dict[str, Any]) -> Dict[str, Any]:
    segments_dict = get_segments(config)
    segment_dict = segments_dict.get(segment_name, None)

    if not segment_dict:
        raise ConfigAttributMissingException(
            f"Segment '{segment_name}' is not configured in config.yaml."
        )

    return segment_dict

def get_exports_of_segment(segment_name:str, config: Dict[str, Any]) -> Dict[str, Any]:
    segment_dict = get_segment(segment_name, config)
    exports = segment_dict.get("exports", None)

    if not exports:
        raise ConfigAttributMissingException(
            f"Exports of the segment '{segment_name}' are not configured in config.yaml."
        )

    return exports


def get_exporters(config: Dict[str, Any]) -> Dict[str, Any]:
    exporters_dict = config.get("exporters", None)

    if not exporters_dict:
        raise ConfigAttributMissingException(
            f"'{SEGMENT_FACTORY}.exporters' not defined in config.yaml"
        )

    return exporters_dict


def get_exporter(exporter_name:str, config: Dict[str, Any]) -> Dict[str, Any]:
    exporters_dict = get_exporters(config)
    exporter_dict = exporters_dict.get(exporter_name, None)

    if not exporter_dict:
        raise ConfigAttributMissingException(
            f"Exporter '{exporter_name}' is not configured in config.yaml."
        )

    return exporter_dict
