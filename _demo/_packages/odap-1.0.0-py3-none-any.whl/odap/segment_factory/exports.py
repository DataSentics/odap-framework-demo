from odap.common.config import get_config_namespace, ConfigNamespace
from odap.segment_factory.config import get_exporter, get_exports_of_segment
from odap.segment_factory.exporters import resolve_exporter, load_exporters_map


def run_export(segment_name: str, exporter: str):
    config = get_config_namespace(ConfigNamespace.SEGMENT_FACTORY)
    exporter_config = get_exporter(exporter, config)
    
    if not exporter in get_exports_of_segment(segment_name, config):
        raise Exception(f"The segment '{segment_name}' has not configured export '{exporter}'.")
    
    exporters_map = load_exporters_map()
    exporter_fce = resolve_exporter(exporter, exporters_map)
    df = exporter_fce(segment_name, exporter_config)
 