import os
import sys
import re
import importlib
from base64 import b64decode
from databricks_cli.workspace.api import WorkspaceApi


def get_repository_root_fs_path() -> str:
    return min([path for path in sys.path if path.startswith("/Workspace/Repos")], key=len)


def get_repository_root_api_path() -> str:
    return re.sub("^/Workspace", "", get_repository_root_fs_path())


def get_absolute_path(*paths: str) -> str:
    return os.path.join(get_repository_root_api_path(), *paths)


def get_notebook_content(notebook_path: str, workspace_api: WorkspaceApi) -> str:
    output = workspace_api.client.export_workspace(notebook_path, format="SOURCE")
    content = output["content"]
    decoded_content = b64decode(content)

    return decoded_content.decode("utf-8")

def import_file(module_name: str, file_path:str):
    module_name = f"odap_exporter_{module_name}"
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module 
    spec.loader.exec_module(module)
    return importlib.import_module(module_name)