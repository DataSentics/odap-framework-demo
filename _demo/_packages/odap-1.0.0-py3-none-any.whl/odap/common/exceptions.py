class ConfigAttributMissingException(Exception):
    pass


class InvalidConfigAttributException(Exception):
    pass


class InvalidNoteboookException(Exception):
    pass
