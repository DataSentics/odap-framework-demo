class ConfigAttributeMissingException(Exception):
    pass


class InvalidConfigAttributException(Exception):
    pass


class InvalidNoteboookException(Exception):
    pass
