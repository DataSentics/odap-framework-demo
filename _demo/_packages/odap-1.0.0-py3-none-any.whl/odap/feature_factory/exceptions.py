class MissingMetadataException(Exception):
    pass
