class MissingMetadataException(Exception):
    pass
